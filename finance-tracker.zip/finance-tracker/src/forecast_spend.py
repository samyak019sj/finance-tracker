"""
Spend Forecasting: Baseline vs ML
-----------------------------------
Aggregates transactions to WEEKLY total spend (debits only), then forecasts
next week's spend using:

  1. Baseline: simple moving average (last 4 weeks)
  2. ML model: RandomForestRegressor / GradientBoostingRegressor using
     lag features (previous weeks' spend) + calendar features

Compares MAE/RMSE of both approaches -- this comparison is the key resume
talking point ("beat baseline by X%"), not the raw error number alone.

Usage:
    python forecast_spend.py
"""

import pandas as pd
import numpy as np
from sklearn.ensemble import RandomForestRegressor, GradientBoostingRegressor
from sklearn.metrics import mean_absolute_error, mean_squared_error

INPUT_FILE = "../data/transactions.csv"

# ----------------------------
# 1. Load and aggregate to weekly spend
# ----------------------------
df = pd.read_csv(INPUT_FILE)
df["date"] = pd.to_datetime(df["date"])

spend_df = df[df["type"] == "debit"].copy()

# Week start (Monday) as the aggregation key
spend_df["week"] = spend_df["date"].dt.to_period("W").apply(lambda p: p.start_time)

weekly = spend_df.groupby("week")["amount"].sum().reset_index()
weekly = weekly.sort_values("week").reset_index(drop=True)
weekly.rename(columns={"amount": "total_spend"}, inplace=True)

print(f"Weekly data points: {len(weekly)}")
print(weekly.head(), "\n")

# ----------------------------
# 2. Feature engineering: lag features + calendar features
# ----------------------------
for lag in [1, 2, 3, 4]:
    weekly[f"lag_{lag}"] = weekly["total_spend"].shift(lag)

weekly["rolling_mean_4"] = weekly["total_spend"].shift(1).rolling(window=4).mean()
weekly["month"] = weekly["week"].dt.month
weekly["week_of_year"] = weekly["week"].dt.isocalendar().week.astype(int)

# Drop early rows with NaNs from lagging
model_df = weekly.dropna().reset_index(drop=True)

# ----------------------------
# 3. Baseline: moving average of last 4 weeks (i.e. rolling_mean_4 IS the baseline prediction)
# ----------------------------
baseline_pred = model_df["rolling_mean_4"]
baseline_actual = model_df["total_spend"]

baseline_mae = mean_absolute_error(baseline_actual, baseline_pred)
baseline_rmse = np.sqrt(mean_squared_error(baseline_actual, baseline_pred))

print(f"Baseline (4-week moving average) -> MAE: {baseline_mae:.2f}, RMSE: {baseline_rmse:.2f}\n")

# ----------------------------
# 4. ML model: train/test split (time-based, not random, since this is a time series)
# ----------------------------
feature_cols = ["lag_1", "lag_2", "lag_3", "lag_4", "rolling_mean_4", "month", "week_of_year"]
X = model_df[feature_cols]
y = model_df["total_spend"]

split_idx = int(len(model_df) * 0.75)  # last 25% of weeks held out as test set
X_train, X_test = X.iloc[:split_idx], X.iloc[split_idx:]
y_train, y_test = y.iloc[:split_idx], y.iloc[split_idx:]

print(f"Train weeks: {len(X_train)}, Test weeks: {len(X_test)}\n")

models = {
    "RandomForest": RandomForestRegressor(n_estimators=200, max_depth=4, random_state=42),
    "GradientBoosting": GradientBoostingRegressor(n_estimators=200, max_depth=3, learning_rate=0.05, random_state=42),
}

results = {}
for name, model in models.items():
    model.fit(X_train, y_train)
    preds = model.predict(X_test)
    mae = mean_absolute_error(y_test, preds)
    rmse = np.sqrt(mean_squared_error(y_test, preds))
    results[name] = {"mae": mae, "rmse": rmse, "preds": preds}
    print(f"{name} -> MAE: {mae:.2f}, RMSE: {rmse:.2f}")

# Baseline on the SAME test window for a fair comparison
baseline_test_mae = mean_absolute_error(y_test, model_df["rolling_mean_4"].iloc[split_idx:])
baseline_test_rmse = np.sqrt(mean_squared_error(y_test, model_df["rolling_mean_4"].iloc[split_idx:]))
print(f"\nBaseline on same test window -> MAE: {baseline_test_mae:.2f}, RMSE: {baseline_test_rmse:.2f}")

# ----------------------------
# 5. Summary: % improvement over baseline
# ----------------------------
print("\n--- SUMMARY ---")
for name, r in results.items():
    improvement = (baseline_test_mae - r["mae"]) / baseline_test_mae * 100
    print(f"{name}: {improvement:+.1f}% MAE improvement over baseline")

# ----------------------------
# 6. Forecast NEXT week's spend using the best model, trained on all data
# ----------------------------
best_model_name = min(results, key=lambda k: results[k]["mae"])
best_model = models[best_model_name]
best_model.fit(X, y)  # retrain on full data for the actual forward forecast

last_row = weekly.iloc[-1]
next_week_features = pd.DataFrame([{
    "lag_1": last_row["total_spend"],
    "lag_2": weekly.iloc[-2]["total_spend"],
    "lag_3": weekly.iloc[-3]["total_spend"],
    "lag_4": weekly.iloc[-4]["total_spend"],
    "rolling_mean_4": weekly["total_spend"].iloc[-4:].mean(),
    "month": (last_row["week"] + pd.Timedelta(weeks=1)).month,
    "week_of_year": (last_row["week"] + pd.Timedelta(weeks=1)).isocalendar()[1],
}])

next_week_pred = best_model.predict(next_week_features)[0]
print(f"\nBest model: {best_model_name}")
print(f"Predicted spend for next week: {next_week_pred:.2f}")
