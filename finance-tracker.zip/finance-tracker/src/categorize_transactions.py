"""
Transaction Categorizer: Rule-Based vs ML
------------------------------------------
Reads transactions.csv (generated earlier), pretends we don't know the
category, predicts it two ways, and compares accuracy against the
ground-truth label:

  1. Rule-based: keyword matching on the transaction description
  2. ML-based:   TF-IDF + Logistic Regression trained on description text

Outputs:
  - categorized_transactions.csv   (predictions from both methods added)
  - Printed accuracy report + confusion matrix for the ML model

Usage:
    python categorize_transactions.py
"""

import pandas as pd
import re
from sklearn.model_selection import train_test_split
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix

INPUT_FILE = "../data/transactions.csv"
OUTPUT_FILE = "../outputs/categorized_transactions.csv"

# ----------------------------
# 1. Load data
# ----------------------------
df = pd.read_csv(INPUT_FILE)
df["date"] = pd.to_datetime(df["date"])

# We only categorize spending (debits). Salary/income is already known.
spend_df = df[df["type"] == "debit"].copy()

# ----------------------------
# 2. Rule-based categorizer
# ----------------------------
# Keyword -> category rules (built by inspecting merchant descriptions)
RULES = {
    "Food & Dining": ["swiggy", "zomato", "dominos", "ccd", "mcdonalds", "starbucks", "restaurant"],
    "Groceries": ["bigbasket", "dmart", "blinkit", "zepto", "reliance fresh"],
    "Transport": ["uber", "ola", "rapido", "metro recharge", "petrol"],
    "Subscriptions": ["netflix", "spotify", "amazon prime", "hotstar", "icloud"],
    "Shopping": ["amazon.in", "flipkart", "myntra", "ajio", "h&m", "festive season"],
    "Utilities": ["electricity", "airtel", "jio fiber", "water dept", "gas agency"],
    "Rent": ["rent payment"],
    "Healthcare": ["apollo pharmacy", "practo", "medplus", "hospital"],
    "Entertainment": ["bookmyshow", "pvr", "gaming", "concert"],
    "Investments": ["zerodha", "groww", "sip auto debit"],
}


def rule_based_predict(description: str) -> str:
    desc = description.lower()
    for category, keywords in RULES.items():
        if any(kw in desc for kw in keywords):
            return category
    return "Anomaly/Other"  # fallback: nothing matched


spend_df["predicted_rule"] = spend_df["description"].apply(rule_based_predict)

rule_accuracy = accuracy_score(spend_df["category_ground_truth"], spend_df["predicted_rule"])
print(f"Rule-based accuracy: {rule_accuracy:.2%}\n")

# ----------------------------
# 3. ML-based categorizer (TF-IDF + Logistic Regression)
# ----------------------------
# Clean description text: remove digits/special chars that don't help classification
def clean_text(text: str) -> str:
    text = text.lower()
    text = re.sub(r"[^a-z\s]", " ", text)
    text = re.sub(r"\s+", " ", text).strip()
    return text


spend_df["clean_description"] = spend_df["description"].apply(clean_text)

X_train, X_test, y_train, y_test = train_test_split(
    spend_df["clean_description"],
    spend_df["category_ground_truth"],
    test_size=0.25,
    random_state=42,
    stratify=spend_df["category_ground_truth"],
)

vectorizer = TfidfVectorizer(ngram_range=(1, 2), min_df=1)
X_train_vec = vectorizer.fit_transform(X_train)
X_test_vec = vectorizer.transform(X_test)

clf = LogisticRegression(max_iter=1000)
clf.fit(X_train_vec, y_train)

y_pred = clf.predict(X_test_vec)
ml_accuracy = accuracy_score(y_test, y_pred)

print(f"ML-based (TF-IDF + Logistic Regression) accuracy: {ml_accuracy:.2%}\n")
print("Classification Report (ML model):")
print(classification_report(y_test, y_pred, zero_division=0))

# ----------------------------
# 4. Predict categories for ALL transactions using the trained ML model
#    (in a real project, this is what you'd run on new/incoming transactions)
# ----------------------------
spend_df["predicted_ml"] = clf.predict(vectorizer.transform(spend_df["clean_description"]))

# ----------------------------
# 5. Save comparison output
# ----------------------------
output_cols = ["date", "description", "amount", "category_ground_truth",
               "predicted_rule", "predicted_ml"]
spend_df[output_cols].to_csv(OUTPUT_FILE, index=False)

print(f"\nSaved detailed predictions -> {OUTPUT_FILE}")
print(f"\nSUMMARY: Rule-based = {rule_accuracy:.2%} | ML-based = {ml_accuracy:.2%}")
