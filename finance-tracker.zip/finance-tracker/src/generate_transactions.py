"""
Simulated Personal Finance Transaction Generator
-------------------------------------------------
Generates 12 months of realistic bank/UPI transaction data for use in a
Personal Finance Tracker + Predictive Insights project.

Output columns:
    date, description, amount, type (debit/credit), category (ground truth,
    kept separately so you can pretend it's unknown and test your classifier)

Usage:
    python generate_transactions.py
"""

import random
import datetime
import csv

random.seed(42)

# ----------------------------
# Config
# ----------------------------
START_DATE = datetime.date(2025, 7, 1)
NUM_MONTHS = 12
MONTHLY_SALARY = 65000  # change to simulate your own income level
OUTPUT_FILE = "../data/transactions.csv"

# Category -> (merchant description templates, min_amt, max_amt, frequency per month)
CATEGORIES = {
    "Food & Dining": {
        "merchants": ["SWIGGY*ORDER", "ZOMATO*ORDER", "DOMINOS PIZZA", "CCD COFFEE",
                      "MCDONALDS", "STARBUCKS", "LOCAL RESTAURANT"],
        "amt_range": (150, 1200),
        "freq_range": (10, 20),
    },
    "Groceries": {
        "merchants": ["BIGBASKET", "DMART", "BLINKIT", "ZEPTO", "RELIANCE FRESH"],
        "amt_range": (300, 3500),
        "freq_range": (4, 8),
    },
    "Transport": {
        "merchants": ["UBER TRIP", "OLA CABS", "RAPIDO", "METRO RECHARGE", "PETROL PUMP"],
        "amt_range": (50, 1500),
        "freq_range": (8, 18),
    },
    "Subscriptions": {
        "merchants": ["NETFLIX.COM", "SPOTIFY", "AMAZON PRIME", "HOTSTAR", "ICLOUD STORAGE"],
        "amt_range": (99, 799),
        "freq_range": (1, 4),
    },
    "Shopping": {
        "merchants": ["AMAZON.IN", "FLIPKART", "MYNTRA", "AJIO", "H&M STORE"],
        "amt_range": (300, 6000),
        "freq_range": (2, 6),
    },
    "Utilities": {
        "merchants": ["ELECTRICITY BOARD", "AIRTEL POSTPAID", "JIO FIBER", "WATER DEPT", "GAS AGENCY"],
        "amt_range": (300, 2500),
        "freq_range": (3, 5),
    },
    "Rent": {
        "merchants": ["RENT PAYMENT - LANDLORD"],
        "amt_range": (12000, 15000),
        "freq_range": (1, 1),
    },
    "Healthcare": {
        "merchants": ["APOLLO PHARMACY", "PRACTO CONSULT", "MEDPLUS", "HOSPITAL BILL"],
        "amt_range": (150, 4000),
        "freq_range": (1, 4),
    },
    "Entertainment": {
        "merchants": ["BOOKMYSHOW", "PVR CINEMAS", "GAMING STORE", "CONCERT TICKETS"],
        "amt_range": (200, 2000),
        "freq_range": (1, 4),
    },
    "Investments": {
        "merchants": ["ZERODHA*ADDFUNDS", "GROWW MUTUAL FUND", "SIP AUTO DEBIT"],
        "amt_range": (2000, 10000),
        "freq_range": (1, 2),
    },
}

# Occasional one-off large/unusual transactions (for anomaly detection later)
ANOMALY_MERCHANTS = ["ELECTRONICS STORE - LAPTOP", "FLIGHT BOOKING", "HOTEL BOOKING",
                     "HOME APPLIANCE STORE", "MEDICAL EMERGENCY"]


def random_day_in_month(year, month):
    if month == 12:
        next_month = datetime.date(year + 1, 1, 1)
    else:
        next_month = datetime.date(year, month + 1, 1)
    days_in_month = (next_month - datetime.date(year, month, 1)).days
    return datetime.date(year, month, random.randint(1, days_in_month))


def generate_transactions():
    rows = []
    current = START_DATE

    for m in range(NUM_MONTHS):
        year = current.year
        month = current.month

        # 1. Salary credit (always on 1st)
        salary_date = datetime.date(year, month, 1)
        salary = MONTHLY_SALARY + random.randint(-1000, 3000)  # small variance/bonus
        rows.append([salary_date, "SALARY CREDIT - EMPLOYER", salary, "credit", "Income"])

        # 2. Category-based spending
        for category, cfg in CATEGORIES.items():
            freq = random.randint(*cfg["freq_range"])
            for _ in range(freq):
                d = random_day_in_month(year, month)
                merchant = random.choice(cfg["merchants"])
                amt = round(random.uniform(*cfg["amt_range"]), 2)
                rows.append([d, merchant, amt, "debit", category])

        # 3. Occasional anomaly (30% chance per month)
        if random.random() < 0.3:
            d = random_day_in_month(year, month)
            merchant = random.choice(ANOMALY_MERCHANTS)
            amt = round(random.uniform(5000, 40000), 2)
            rows.append([d, merchant, amt, "debit", "Anomaly/Other"])

        # 4. Simulate slight seasonal effects (e.g., Nov-Dec festive spending spike)
        if month in (11, 12):
            d = random_day_in_month(year, month)
            amt = round(random.uniform(2000, 10000), 2)
            rows.append([d, "FESTIVE SEASON SHOPPING", amt, "debit", "Shopping"])

        # move to next month
        if month == 12:
            current = datetime.date(year + 1, 1, 1)
        else:
            current = datetime.date(year, month + 1, 1)

    rows.sort(key=lambda r: r[0])
    return rows


def save_csv(rows, filename):
    with open(filename, "w", newline="") as f:
        writer = csv.writer(f)
        writer.writerow(["date", "description", "amount", "type", "category_ground_truth"])
        for r in rows:
            writer.writerow(r)


if __name__ == "__main__":
    data = generate_transactions()
    save_csv(data, OUTPUT_FILE)
    print(f"Generated {len(data)} transactions across {NUM_MONTHS} months -> {OUTPUT_FILE}")
