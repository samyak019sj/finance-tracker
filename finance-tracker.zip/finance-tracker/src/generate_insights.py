"""
Anomaly Detection & Insights Layer
------------------------------------
Takes transactions.csv and produces:

  1. Anomaly flags: transactions that are unusually large relative to their
     category's historical spend (z-score / IQR based, not hardcoded rules)
  2. New recurring subscription detection: merchants that started appearing
     regularly in recent months but weren't seen before
  3. Category spend spike detection: month-over-month % change per category
  4. A plain-English monthly summary (the "insight" a real app would show)

Usage:
    python generate_insights.py
"""

import pandas as pd
import numpy as np

INPUT_FILE = "../data/transactions.csv"

df = pd.read_csv(INPUT_FILE)
df["date"] = pd.to_datetime(df["date"])
df["month"] = df["date"].dt.to_period("M")

spend_df = df[df["type"] == "debit"].copy()

# ============================================================
# 1. ANOMALY DETECTION (per-category, IQR method)
# ============================================================
grouped = spend_df.groupby("category_ground_truth")["amount"]
q1 = grouped.transform(lambda x: x.quantile(0.25))
q3 = grouped.transform(lambda x: x.quantile(0.75))
iqr = q3 - q1
upper_bound = q3 + 1.5 * iqr
spend_df["is_anomaly"] = spend_df["amount"] > upper_bound

anomalies = spend_df[spend_df["is_anomaly"]].sort_values("amount", ascending=False)

print("=" * 60)
print("ANOMALOUS TRANSACTIONS (unusually large for their category)")
print("=" * 60)
if len(anomalies) == 0:
    print("No anomalies detected.")
else:
    for _, row in anomalies.iterrows():
        print(f"  {row['date'].date()} | {row['description']:<30} | Rs.{row['amount']:>10,.2f} | {row['category_ground_truth']}")

# ============================================================
# 2. NEW RECURRING SUBSCRIPTION DETECTION
# ============================================================
# Logic: a merchant is "newly recurring" if it appears in the most recent
# 2 months but had zero occurrences in all months before that.
print("\n" + "=" * 60)
print("NEW RECURRING MERCHANTS (appeared recently, not seen before)")
print("=" * 60)

all_months = sorted(spend_df["month"].unique())
recent_months = all_months[-2:]
older_months = all_months[:-2]

recent_merchants = set(spend_df[spend_df["month"].isin(recent_months)]["description"])
older_merchants = set(spend_df[spend_df["month"].isin(older_months)]["description"])

new_merchants = recent_merchants - older_merchants
if new_merchants:
    for m in sorted(new_merchants):
        print(f"  - {m}")
else:
    print("  None found.")

# ============================================================
# 3. MONTH-OVER-MONTH CATEGORY SPEND SPIKES
# ============================================================
print("\n" + "=" * 60)
print("CATEGORY SPEND: MONTH-OVER-MONTH % CHANGE (latest vs previous)")
print("=" * 60)

monthly_cat = spend_df.groupby(["month", "category_ground_truth"])["amount"].sum().reset_index()
pivot = monthly_cat.pivot(index="month", columns="category_ground_truth", values="amount").fillna(0)
pivot = pivot.sort_index()

if len(pivot) >= 2:
    latest = pivot.iloc[-1]
    previous = pivot.iloc[-2]
    pct_change = ((latest - previous) / previous.replace(0, np.nan) * 100).fillna(0)
    pct_change = pct_change.sort_values(ascending=False)

    for cat, pct in pct_change.items():
        direction = "up" if pct > 0 else "down"
        print(f"  {cat:<20}: {direction} {abs(pct):.1f}%  (Rs.{previous[cat]:,.0f} -> Rs.{latest[cat]:,.0f})")
else:
    print("  Not enough months of data.")

# ============================================================
# 4. PLAIN-ENGLISH MONTHLY SUMMARY (the "insight" layer)
# ============================================================
print("\n" + "=" * 60)
print("MONTHLY SUMMARY (auto-generated, plain English)")
print("=" * 60)

latest_month = all_months[-1]
latest_month_df = spend_df[spend_df["month"] == latest_month]
total_spend_latest = latest_month_df["amount"].sum()

top_category = latest_month_df.groupby("category_ground_truth")["amount"].sum().idxmax()
top_category_amt = latest_month_df.groupby("category_ground_truth")["amount"].sum().max()

biggest_mover = pct_change.abs().idxmax() if len(pivot) >= 2 else None
biggest_mover_pct = pct_change[biggest_mover] if biggest_mover else None

summary_lines = []
summary_lines.append(f"In {latest_month}, you spent a total of Rs.{total_spend_latest:,.0f}.")
summary_lines.append(f"Your top spending category was {top_category} at Rs.{top_category_amt:,.0f}.")

if biggest_mover is not None:
    direction = "increased" if biggest_mover_pct > 0 else "decreased"
    summary_lines.append(
        f"Your {biggest_mover} spending {direction} by {abs(biggest_mover_pct):.0f}% compared to last month."
    )

if len(anomalies) > 0:
    top_anomaly = anomalies.iloc[0]
    summary_lines.append(
        f"We flagged an unusually large transaction: '{top_anomaly['description']}' for Rs.{top_anomaly['amount']:,.0f}."
    )

if new_merchants:
    summary_lines.append(
        f"You started transacting with {len(new_merchants)} new merchant(s) recently, including '{sorted(new_merchants)[0]}'."
    )

for line in summary_lines:
    print(f"  - {line}")

# Save summary + anomalies to files for use in the dashboard later
anomalies.to_csv("../outputs/anomalies.csv", index=False)
with open("../outputs/monthly_summary.txt", "w") as f:
    f.write("\n".join(summary_lines))

print("\nSaved: anomalies.csv, monthly_summary.txt")
